import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const next = searchParams.get("next") || "/";
  if (code) await createClient().auth.exchangeCodeForSession(code);
  return NextResponse.redirect(`${origin}${next.startsWith("/") ? next : "/"}`);
}
